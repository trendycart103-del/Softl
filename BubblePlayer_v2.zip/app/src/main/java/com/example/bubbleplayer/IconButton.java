package com.example.bubbleplayer;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;

/** কন্ট্রোল বোতাম। type: 0=আগের 1=প্লে/পজ 2=পরের 3=সেটিং 4=শাফল 5=রিপিট 6=তালিকা 7=বন্ধ */
public class IconButton extends View {
    int type, color = 0xFF4FC3F7; boolean playing, active, one, big = true;
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    float press = 1f;

    public IconButton(Context c, int type) {
        super(c);
        this.type = type;
        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    void set(boolean playing, int color) { this.playing = playing; this.color = color; invalidate(); }
    void setActive(boolean a, boolean one) { this.active = a; this.one = one; invalidate(); }
    IconButton small() { big = false; return this; }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) { press = 0.9f; invalidate(); }
        else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) { press = 1f; invalidate(); }
        return super.onTouchEvent(e);
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), cx = w / 2, cy = getHeight() / 2, r = w / 2 * 0.84f * press;
        int dark = Color.argb(235, Color.red(color) / 3, Color.green(color) / 3, Color.blue(color) / 3);
        p.setStrokeCap(Paint.Cap.BUTT); p.clearShadowLayer(); p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        if (big) {
            p.setShadowLayer(w * 0.08f, 0, 0, color);
            p.setShader(new RadialGradient(cx - r / 3, cy - r / 3, r * 1.4f, (color & 0x00FFFFFF) | 0xDD000000, dark, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, p);
            p.setShader(null); p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w * 0.03f); p.setColor(0xCCFFFFFF);
            c.drawCircle(cx, cy, r, p);
        } else {
            p.setColor(active ? ((color & 0x00FFFFFF) | 0x55000000) : 0x22FFFFFF);
            c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w * 0.025f);
            p.setColor(active ? color : 0x55FFFFFF);
            c.drawCircle(cx, cy, r, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor((!big && !active) ? 0xCCFFFFFF : (big ? Color.WHITE : color));
        float s = r * 0.42f;
        Path t = new Path();
        switch (type) {
            case 1:
                if (playing) {
                    c.drawRoundRect(cx - s * 0.8f, cy - s, cx - s * 0.2f, cy + s, 6, 6, p);
                    c.drawRoundRect(cx + s * 0.2f, cy - s, cx + s * 0.8f, cy + s, 6, 6, p);
                } else {
                    t.moveTo(cx - s * 0.6f, cy - s); t.lineTo(cx + s, cy); t.lineTo(cx - s * 0.6f, cy + s); t.close();
                    c.drawPath(t, p);
                }
                break;
            case 0: case 2: {
                float d = type == 2 ? 1 : -1;
                t.moveTo(cx - d * s * 0.3f, cy - s * 0.8f); t.lineTo(cx + d * s * 0.7f, cy); t.lineTo(cx - d * s * 0.3f, cy + s * 0.8f); t.close();
                c.drawPath(t, p);
                float bx = cx - d * s * 0.7f;
                c.drawRoundRect(bx - s * 0.12f, cy - s * 0.8f, bx + s * 0.12f, cy + s * 0.8f, 4, 4, p);
                break;
            }
            case 4: {
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w * 0.045f); p.setStrokeCap(Paint.Cap.ROUND);
                float a = s * 1.1f;
                Path q = new Path();
                q.moveTo(cx - a, cy - a * 0.6f); q.cubicTo(cx, cy - a * 0.6f, cx, cy + a * 0.6f, cx + a * 0.8f, cy + a * 0.6f);
                q.moveTo(cx - a, cy + a * 0.6f); q.cubicTo(cx, cy + a * 0.6f, cx, cy - a * 0.6f, cx + a * 0.8f, cy - a * 0.6f);
                c.drawPath(q, p);
                p.setStyle(Paint.Style.FILL);
                arrow(c, cx + a, cy + a * 0.6f); arrow(c, cx + a, cy - a * 0.6f);
                break;
            }
            case 5: {
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(w * 0.045f); p.setStrokeCap(Paint.Cap.ROUND);
                float a = s * 1.0f;
                c.drawArc(cx - a, cy - a, cx + a, cy + a, 30, 290, false, p);
                p.setStyle(Paint.Style.FILL);
                arrow(c, cx + a * 0.87f, cy + a * 0.5f);
                if (one) { p.setTextAlign(Paint.Align.CENTER); p.setTextSize(r * 0.7f); c.drawText("1", cx, cy + r * 0.25f, p); }
                break;
            }
            case 6: {
                p.setStrokeWidth(w * 0.05f); p.setStrokeCap(Paint.Cap.ROUND); p.setStyle(Paint.Style.STROKE);
                for (int k = -1; k <= 1; k++) c.drawLine(cx - s, cy + k * s * 0.7f, cx + s, cy + k * s * 0.7f, p);
                break;
            }
            case 7: {
                p.setStrokeWidth(w * 0.05f); p.setStrokeCap(Paint.Cap.ROUND); p.setStyle(Paint.Style.STROKE);
                c.drawLine(cx - s * 0.7f, cy - s * 0.7f, cx + s * 0.7f, cy + s * 0.7f, p);
                c.drawLine(cx - s * 0.7f, cy + s * 0.7f, cx + s * 0.7f, cy - s * 0.7f, p);
                break;
            }
            default: {
                p.setStrokeWidth(w * 0.045f); p.setStrokeCap(Paint.Cap.ROUND); p.setStyle(Paint.Style.STROKE);
                c.drawLine(cx - s, cy - s * 0.6f, cx + s, cy - s * 0.6f, p);
                c.drawLine(cx - s, cy + s * 0.6f, cx + s, cy + s * 0.6f, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx + s * 0.3f, cy - s * 0.6f, s * 0.28f, p);
                c.drawCircle(cx - s * 0.3f, cy + s * 0.6f, s * 0.28f, p);
            }
        }
    }

    void arrow(Canvas c, float x, float y) {
        Path t = new Path(); float k = getWidth() * 0.06f;
        t.moveTo(x + k, y); t.lineTo(x - k * 0.4f, y - k); t.lineTo(x - k * 0.4f, y + k); t.close();
        c.drawPath(t, p);
    }
}
