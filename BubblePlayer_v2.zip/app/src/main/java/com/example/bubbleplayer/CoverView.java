package com.example.bubbleplayer;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/** গোল ঘুরন্ত কভার: নিয়ন গ্লো রিং + রেকর্ডের খাঁজ + মাঝের ছিদ্র। */
public class CoverView extends View {
    Bitmap bmp; boolean spin; int color = 0xFF4FC3F7; float ang;
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), ring = new Paint(Paint.ANTI_ALIAS_FLAG), groove = new Paint(Paint.ANTI_ALIAS_FLAG);
    Matrix m = new Matrix();

    public CoverView(Context c) {
        super(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        ring.setStyle(Paint.Style.STROKE);
        groove.setStyle(Paint.Style.STROKE);
    }

    void set(Bitmap b, boolean s, int col) {
        boolean restart = s && !spin;
        bmp = b; spin = s; color = col;
        if (restart) postInvalidateOnAnimation(); else invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), cx = w / 2, cy = getHeight() / 2, R = w / 2 - w * 0.07f;
        ring.setStrokeWidth(w * 0.03f);
        ring.setColor(color);
        ring.setShadowLayer(w * 0.06f, 0, 0, color);
        c.drawCircle(cx, cy, R + w * 0.028f, ring);
        ring.clearShadowLayer();
        c.save();
        c.rotate(ang, cx, cy);
        if (bmp != null) {
            BitmapShader sh = new BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            float sc = 2 * R / Math.min(bmp.getWidth(), bmp.getHeight());
            m.reset(); m.setScale(sc, sc);
            m.postTranslate(cx - bmp.getWidth() * sc / 2, cy - bmp.getHeight() * sc / 2);
            sh.setLocalMatrix(m);
            p.setShader(sh);
            c.drawCircle(cx, cy, R, p);
        } else {
            p.setShader(new LinearGradient(cx - R, cy - R, cx + R, cy + R, color, PlayerCore.accent2(), Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, R, p);
            p.setShader(null);
            p.setColor(0xDDFFFFFF); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(R * 1.1f);
            c.drawText("♪", cx, cy + R * 0.38f, p);
        }
        p.setShader(null);
        groove.setStrokeWidth(Math.max(1f, w * 0.004f));
        groove.setColor(0x22000000);
        for (float f = 0.45f; f < 0.97f; f += 0.13f) c.drawCircle(cx, cy, R * f, groove);
        groove.setColor(0x33FFFFFF); groove.setStrokeWidth(w * 0.012f);
        c.drawArc(cx - R * 0.8f, cy - R * 0.8f, cx + R * 0.8f, cy + R * 0.8f, -60, 40, false, groove);
        c.restore();
        p.setColor(0xFF0B1220);
        c.drawCircle(cx, cy, R * 0.14f, p);
        p.setColor(color); p.setAlpha(200);
        c.drawCircle(cx, cy, R * 0.05f, p);
        p.setAlpha(255);
        if (spin) { ang = (ang + 0.7f) % 360; postInvalidateOnAnimation(); }
    }
}
