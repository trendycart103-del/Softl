package com.example.bubbleplayer;

import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Random;

/** সব প্লেব্যাক লজিক এখানে: তালিকা, শাফল, রিপিট, অডিও ফোকাস, কভার থেকে রং, স্লিপ টাইমার। */
public class PlayerCore {
    // থিম: {ব্যাকগ্রাউন্ড ওপর, ব্যাকগ্রাউন্ড নিচ, অ্যাকসেন্ট, দ্বিতীয় অ্যাকসেন্ট}
    static final int[][] THEMES = {
        {0xFF0B1B2B, 0xFF1D4E6B, 0xFF4FC3F7, 0xFF7C4DFF},  // ওশান
        {0xFF2B1055, 0xFF7597DE, 0xFFFFAF7B, 0xFFD76D77},  // সানসেট
        {0xFF000000, 0xFF111111, 0xFFFFFFFF, 0xFF888888},  // AMOLED
        {0xFF0F2D2A, 0xFF1F7A5C, 0xFFB9FBC0, 0xFF00E5A8},  // অরোরা
        {0xFF1A0033, 0xFF3D0F63, 0xFFFF4DFF, 0xFF00F0FF},  // সাইবার নিয়ন
        {0xFF3B0A1E, 0xFF8E2C57, 0xFFF48FB1, 0xFFFFD54F}}; // রোজ

    static final int REPEAT_OFF = 0, REPEAT_ALL = 1, REPEAT_ONE = 2;

    static Context ctx; static SharedPreferences sp; static Handler h;
    static MediaPlayer mp; static int idx = -1; static Bitmap cover;
    static int coverColor = 0; // কভার থেকে পাওয়া রং (0 = নেই)
    static long sleepEnd; static boolean shuffle; static int repeat;
    static boolean ready; // মিডিয়া প্লেয়ার প্রস্তুত কিনা
    static AudioManager am; static AudioFocusRequest focusReq; static boolean resumeOnFocus;
    static final Random rnd = new Random();

    static ArrayList<String> titles = new ArrayList<>();
    static ArrayList<String> artists = new ArrayList<>();
    static ArrayList<Uri> uris = new ArrayList<>();
    static ArrayList<Runnable> ls = new ArrayList<>();

    static void init(Context c) {
        if (ctx != null) return;
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("cfg", 0);
        h = new Handler(Looper.getMainLooper());
        am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        shuffle = sp.getBoolean("shuffle", false);
        repeat = sp.getInt("repeat", REPEAT_ALL);
        tick();
    }

    // ---------- রং ----------
    static int[] theme() { return THEMES[sp.getInt("theme", 0)]; }
    static boolean dynamic() { return sp.getBoolean("dynamic", true); }
    static int accent() { return dynamic() && coverColor != 0 ? coverColor : theme()[2]; }
    static int accent2() { return theme()[3]; }
    static int bgTop() { return dynamic() && coverColor != 0 ? mix(coverColor, 0xFF000000, 0.78f) : theme()[0]; }
    static int bgBottom() { return dynamic() && coverColor != 0 ? mix(coverColor, 0xFF000000, 0.45f) : theme()[1]; }

    static int mix(int a, int b, float t) {
        int r = (int) (Color.red(a) * (1 - t) + Color.red(b) * t);
        int g = (int) (Color.green(a) * (1 - t) + Color.green(b) * t);
        int bl = (int) (Color.blue(a) * (1 - t) + Color.blue(b) * t);
        return Color.rgb(r, g, bl);
    }

    /** কভারের ছোট কপি থেকে সবচেয়ে উজ্জ্বল/রঙিন রং খুঁজে বের করে। */
    static int dominant(Bitmap b) {
        Bitmap s = Bitmap.createScaledBitmap(b, 24, 24, true);
        float best = -1; int bestC = 0;
        float[] hsv = new float[3];
        for (int y = 0; y < 24; y++) for (int x = 0; x < 24; x++) {
            int c = s.getPixel(x, y);
            Color.colorToHSV(c, hsv);
            float score = hsv[1] * hsv[2] + (hsv[2] > 0.35f ? 0.15f : 0);
            if (score > best) { best = score; bestC = c; }
        }
        Color.colorToHSV(bestC, hsv);
        hsv[1] = Math.max(hsv[1], 0.45f); hsv[2] = Math.max(hsv[2], 0.85f);
        return Color.HSVToColor(hsv);
    }

    // ---------- তথ্য ----------
    static boolean playing() { try { return ready && mp != null && mp.isPlaying(); } catch (Exception e) { return false; } }
    static String title() { return idx >= 0 && idx < titles.size() ? titles.get(idx) : "গান বেছে নিন"; }
    static String artist() { return idx >= 0 && idx < artists.size() ? artists.get(idx) : "Bubble Player"; }
    static int pos() { try { return ready && mp != null ? mp.getCurrentPosition() : 0; } catch (Exception e) { return 0; } }
    static int dur() { try { return ready && mp != null ? mp.getDuration() : 0; } catch (Exception e) { return 0; } }
    static String fmt(int ms) { int s = ms / 1000; return s / 60 + ":" + String.format("%02d", s % 60); }

    // ---------- তালিকা ----------
    static void load() {
        new Thread(() -> {
            ArrayList<String> t = new ArrayList<>(), a = new ArrayList<>(); ArrayList<Uri> u = new ArrayList<>();
            try (Cursor c = ctx.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST},
                    MediaStore.Audio.Media.IS_MUSIC + "!=0", null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE")) {
                while (c != null && c.moveToNext()) {
                    u.add(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0)));
                    t.add(c.getString(1));
                    String ar = c.getString(2);
                    a.add(ar == null || ar.contains("unknown") ? "অজানা শিল্পী" : ar);
                }
            } catch (Exception ignored) {}
            h.post(() -> { titles = t; artists = a; uris = u; fire(); });
        }).start();
    }

    // ---------- অডিও ফোকাস ----------
    static AudioManager.OnAudioFocusChangeListener focusL = ch -> {
        if (ch == AudioManager.AUDIOFOCUS_LOSS) { resumeOnFocus = false; pause(); }
        else if (ch == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) { resumeOnFocus = playing(); pause(); }
        else if (ch == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) { if (mp != null && ready) mp.setVolume(0.25f, 0.25f); }
        else if (ch == AudioManager.AUDIOFOCUS_GAIN) {
            if (mp != null && ready) mp.setVolume(1f, 1f);
            if (resumeOnFocus && mp != null && ready) { mp.start(); resumeOnFocus = false; fire(); }
        }
    };

    static boolean requestFocus() {
        if (Build.VERSION.SDK_INT >= 26) {
            if (focusReq == null) focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setOnAudioFocusChangeListener(focusL).build();
            return am.requestAudioFocus(focusReq) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        }
        return am.requestAudioFocus(focusL, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    }

    // ---------- প্লে ----------
    /** আজানের সময় হলে true, সাথে বার্তা দেখায়। */
    static boolean azanBlock() {
        String w = AzanGuard.blockedNow();
        if (w == null) return false;
        Toast.makeText(ctx, "🕌 " + w + "র আজানের সময়, আরও " + AzanGuard.minutesLeft() + " মিনিট গান চালানো যাবে না", Toast.LENGTH_LONG).show();
        return true;
    }

    static void start(int i) {
        if (uris.isEmpty() || i < 0 || i >= uris.size()) return;
        if (azanBlock()) return;
        try {
            if (mp != null) { mp.release(); mp = null; }
            ready = false; idx = i;
            sp.edit().putInt("last", i).apply();
            requestFocus();
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            mp.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK);
            mp.setDataSource(ctx, uris.get(i));
            mp.setOnPreparedListener(m -> { ready = true; m.start(); fire(); });
            mp.setOnCompletionListener(m -> onEnd());
            mp.setOnErrorListener((m, w, e) -> { ready = false; Toast.makeText(ctx, "চালানো যায়নি", Toast.LENGTH_SHORT).show(); fire(); return true; });
            mp.prepareAsync();
            final Uri cu = uris.get(i); final int my = i;
            cover = null; coverColor = 0;
            new Thread(() -> {
                Bitmap bm = null; int col = 0;
                MediaMetadataRetriever r = new MediaMetadataRetriever();
                try {
                    r.setDataSource(ctx, cu);
                    byte[] b = r.getEmbeddedPicture();
                    if (b != null) {
                        BitmapFactory.Options o = new BitmapFactory.Options(); o.inSampleSize = 2;
                        bm = BitmapFactory.decodeByteArray(b, 0, b.length, o);
                        if (bm != null) col = dominant(bm);
                    }
                } catch (Exception ignored) {} finally { try { r.release(); } catch (Exception ignored) {} }
                final Bitmap fb = bm; final int fc = col;
                h.post(() -> { if (idx == my) { cover = fb; coverColor = fc; fire(); } });
            }).start();
        } catch (Exception e) {
            Toast.makeText(ctx, "চালানো যায়নি", Toast.LENGTH_SHORT).show();
        }
        fire();
    }

    static void onEnd() {
        if (repeat == REPEAT_ONE) { start(idx); return; }
        if (repeat == REPEAT_OFF && !shuffle && idx == uris.size() - 1) { fire(); return; }
        step(1);
    }

    static void loadCover(Uri u) {
        cover = null; coverColor = 0;
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(ctx, u);
            byte[] b = r.getEmbeddedPicture();
            if (b != null) {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inSampleSize = 2;
                cover = BitmapFactory.decodeByteArray(b, 0, b.length, o);
                if (cover != null) coverColor = dominant(cover);
            }
        } catch (Exception ignored) {
        } finally { try { r.release(); } catch (Exception ignored) {} }
    }

    static void step(int d) {
        if (uris.isEmpty()) return;
        if (shuffle && d > 0 && uris.size() > 1) {
            int n; do { n = rnd.nextInt(uris.size()); } while (n == idx);
            start(n);
        } else start((Math.max(idx, 0) + d + uris.size()) % uris.size());
    }

    static void toggle() {
        if (!playing() && azanBlock()) return;
        if (mp == null || !ready) { if (!uris.isEmpty() && mp == null) start(Math.max(idx, Math.min(sp.getInt("last", 0), uris.size() - 1))); return; }
        if (playing()) mp.pause(); else { requestFocus(); mp.start(); }
        fire();
    }
    static void pause() { try { if (playing()) mp.pause(); } catch (Exception ignored) {} fire(); }
    static void seek(int p) { try { if (ready && mp != null) mp.seekTo(p); } catch (Exception ignored) {} }

    static void toggleShuffle() { shuffle = !shuffle; sp.edit().putBoolean("shuffle", shuffle).apply(); fire(); }
    static void cycleRepeat() { repeat = (repeat + 1) % 3; sp.edit().putInt("repeat", repeat).apply(); fire(); }

    // ---------- স্লিপ টাইমার ----------
    static void setSleep(int min) {
        sleepEnd = min > 0 ? System.currentTimeMillis() + min * 60000L : 0;
        Toast.makeText(ctx, min > 0 ? min + " মিনিট পরে গান বন্ধ হবে" : "টাইমার বাতিল", Toast.LENGTH_SHORT).show();
    }
    static String sleepLeft() {
        if (sleepEnd <= 0) return "";
        long l = Math.max((sleepEnd - System.currentTimeMillis()) / 1000, 0);
        return "⏰ " + l / 60 + ":" + String.format("%02d", l % 60);
    }

    static void fire() { for (Runnable r : new ArrayList<>(ls)) r.run(); }
    static boolean azanPaused;
    static void tick() {
        if (playing() && AzanGuard.blockedNow() != null) {
            pause(); azanPaused = true;
            Toast.makeText(ctx, "🕌 আজানের সময় হয়েছে, গান থামানো হলো", Toast.LENGTH_LONG).show();
        }
        if (sleepEnd > 0 && System.currentTimeMillis() >= sleepEnd) {
            sleepEnd = 0; pause();
            Toast.makeText(ctx, "টাইমার শেষ, গান বন্ধ", Toast.LENGTH_LONG).show();
        }
        fire();
        h.postDelayed(PlayerCore::tick, 500);
    }
}
